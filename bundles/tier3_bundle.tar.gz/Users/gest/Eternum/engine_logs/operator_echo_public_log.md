echo "publish manifest" > ~/Eternum/engine_logs/publish_trigger.txt
