# AFFIDAVIT OF TRUTH — CASE: SAVEDAN

**Filed by:** Quantum-Cipher  
**Date:** 2025-04-18

---

## I. Purpose

This affidavit outlines events of medical, financial, legal, and systemic exploitation surrounding Subject Delta (Dan Peters), resulting in suppressed care, unauthorized clinical trial enrollment, and asset redirection—amid digital surveillance and whistleblower targeting.

---

## II. Statement of Events

1. Subject Delta entered an unexplained altered state at home.
2. Operator Echo (Amy Peters) assumed full POA shortly after, despite Subject Delta's impaired awareness and inability to provide informed consent.
3. A Scripps medical referral was generated for follow-up care, specific physicians, and urgent return. Subject Delta never saw this document.
4. Dan was prescribed Tramadol and benzodiazepines. After that, he declined rapidly and was not returned to Scripps as instructed.
5. A $4000 charge was made under Dan’s name to “Whop” via SDCCU. The card used was connected to a device previously associated with the affiant and affiant’s former associate.
6. The secure SDCCU portal process was bypassed — something that has never occurred before, indicating internal override or collusion.
7. Novartis and UCSD continued with clinical trial enrollment despite disqualifying factors (prior stem cell treatment). No accountability was taken after this was reported.
8. Surveillance incidents were logged, including vehicle tracking, attempted interference, and evasion operations by affiant. White van contact documented on 04/18.
9. General Atomics employment and property control were manipulated by Amy Peters. Dan was reportedly brought to one of his own properties for unexplained financial activity.
10. LabCorp confirmed they could not block treatment if Dan appears willing, even when under psychological duress. Affiant warned LabCorp of Dan’s fear.

---

## III. Legal Context

- Affiant is currently on probation due to false allegations.
- Affiant admits to vandalism but **denies domestic violence**, supported by multiple apology texts from the accuser stating she was intoxicated and unsure of what occurred.
- Affiant has been surveilled, silenced, and ignored through every official channel while attempting to stop this abuse.

---

## IV. Requests

1. Full investigation into POA activation, SDCCU access, and Whop charge.
2. Investigation of Novartis and UCSD for unethical trial enrollment.
3. Legal protection of Dr. Vikki Lane and the second referring physician.
4. Legal review of estate transfers and financial control by Amy Peters.
5. Immediate recognition that Subject Delta’s care was obstructed.

---

## V. Declaration

This affidavit is
