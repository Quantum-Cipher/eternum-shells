#!/bin/zsh

LOG_DIR="$HOME/Eternum/engine_logs/long_logs"
LOG_FILE="$LOG_DIR/log_$(date +%Y%m%d_%H%M).md"

mkdir -p "$LOG_DIR"

# Start log with a timestamp header
echo "# 📓 Eternum Long Log — $(date)" >> "$LOG_FILE"

# Append recent events
echo "## 🔁 Whisper Loop Snapshot:" >> "$LOG_FILE"
tail -n 20 ~/Eternum/engine_logs/whisper_log_0418.txt >> "$LOG_FILE"

echo "\n## 🔍 System Daemon Snapshot:" >> "$LOG_FILE"
tail -n 20 ~/Eternum/intel/system_logs/launchctl_list.log >> "$LOG_FILE"

echo "\n## 📡 Network Activity:" >> "$LOG_FILE"
tail -n 20 ~/Eternum/intel/network_logs/established_connections.log >> "$LOG_FILE"

echo "\n✅ Log auto-appended to: $LOG_FILE"
