#!/bin/zsh

LOG="$HOME/Eternum/engine_logs/bridgehunter_log_$(date +%Y%m%d_%H%M).txt"
mkdir -p "$(dirname "$LOG")"

echo "🌉 BRIDGEHUNTER PROTOCOL ACTIVE — $(date)" > "$LOG"

# Monitor DNS bridge requests (Port 53)
echo "\n🔍 Tracking DNS-level access attempts..." >> "$LOG"
lsof -i :53 >> "$LOG" 2>/dev/null

# Monitor open VPN ports (1194, 51820, 443 tunnel attempts)
PORTS=("1194" "51820" "443")

for port in $PORTS; do
  PIDS=$(lsof -iTCP:$port -sTCP:ESTABLISHED -t 2>/dev/null)
  for pid in $PIDS; do
    echo "🕵️‍♂️ Bridge Interference Detected: PID $pid on Port $port" >> "$LOG"
    echo "bridge:$pid:$port" >> ~/Eternum/intel/network_logs/bridge_intercepts.log
    kill -STOP $pid && sleep 0.5 && kill -CONT $pid &
  done
done

echo "\n✅ Bridgehunter complete. Logged and looped threats." >> "$LOG"
