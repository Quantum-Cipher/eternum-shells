import json
from datetime import datetime, timezone
from pathlib import Path

# Path config
discovery_file = Path.home() / "Eternum/tmp/discovery_results.txt"
index_file = Path.home() / "Eternum/intel/surveillance_dataset/index.json"

# Load previous dataset if exists
if index_file.exists():
    with open(index_file, "r") as f:
        dataset = json.load(f)
else:
    dataset = {
        "created": datetime.now(timezone.utc).isoformat(),
        "dataset_name": "Eternum Surveillance Manifest",
        "analyst": "Quantum Cipher",
        "source": "filtered_auto_discovery",
        "entries": []
    }

# Load discovery results
with open(discovery_file, "r") as f:
    lines = f.read().splitlines()

# Only process encrypted formats
encrypted_exts = [".gpg", ".vault", ".enc", ".asc"]
sensitive_keywords = ["wallet", "claim", "affidavit", "guardian", "identity"]

for path in lines:
    file_path = Path(path)
    if file_path.suffix.lower() in encrypted_exts:
        flags = [kw for kw in sensitive_keywords if kw in file_path.name.lower()]
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "method": "encrypted_discovery",
            "actor": "unknown",
            "impact": "pending_risk_analysis",
            "proof": path,
            "category": "encrypted_metadata",
            "flags": flags
        }
        dataset["entries"].append(entry)

# Save updated dataset
with open(index_file, "w") as out_file:
    json.dump(dataset, out_file, indent=2)

print("🔐 Encrypted-only entries appended to surveillance dataset.")
