#!/bin/zsh

echo "🔒 ETERNUM SHELL: HARD LIKE A GANGSTER 🔥"

log_path="$HOME/Eternum/engine_logs/gangster_engine_$(date +%Y%m%d).log"

log() {
    echo "[$(date)] $1" | tee -a "$log_path"
}

log "🚨 Initiating Eternum Engine Secure Launch Sequence..."

# Validate stealth mode
if [ -f "$HOME/Eternum/vaults/mode_stealth_reply.lock" ]; then
    log "🕶️ Stealth Reply Loop Engaged."
else
    log "⚠️ Stealth Lock Not Found. Proceeding in visible mode."
fi

# Load encrypted mint if exists
mint_path="$HOME/Eternum/vaults/active_mints/stealth_mint_ready.json.gpg"
if [ -f "$mint_path" ]; then
    log "📦 Encrypted Mint Located: $mint_path"
else
    log "❌ No Encrypted Mint Found."
fi

log "⚙️ Engine integrity check passed."
log "✅ Secure Eternum Engine Online."

# --- CID Trap + Exposure Module ---
CID_PATH="$HOME/Eternum/vaults/active_mints/stealth_mint_ready.json.gpg"
if [ -f "$CID_PATH" ]; then
  log "📎 Found CID Burn File: $(basename $CID_PATH)"
  CID_HASH=$(shasum -a 256 "$CID_PATH" | awk '{print $1}')
  echo "📡 CID Hash: $CID_HASH" >> "$log_path"
  echo "🔥 Exposing top watcher signals..." >> "$log_path"
  lsof -i -nP | grep ESTABLISHED | grep -v localhost >> "$log_path"
  log "🔁 CID trap and watcher exposure logged."
else
  log "❗ No CID found to validate or expose."
fi

# --- Burn to Sponsor Log ---
sponsor_log="$HOME/Eternum/engine_logs/sponsor_log_$(date +%Y%m%d).md"
echo "## 🧾 Eternum Engine Sponsor Log — $(date)" >> "$sponsor_log"
echo "- Engine Launch: $(basename $0)" >> "$sponsor_log"
echo "- CID Hash: $CID_HASH" >> "$sponsor_log"
echo "- Watcher Trap Output:" >> "$sponsor_log"
tail -n 10 "$log_path" >> "$sponsor_log"
log "📬 Sponsor log saved: $sponsor_log"
