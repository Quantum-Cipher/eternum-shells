from datetime import datetime
import re

WATCHLIST = ["keystone", "googleupdater", "edgeupdater", "remoteadmin", "deepseek", "novartis", "mdm", "watchdog", "mirroring", "telemetry", "scripps"]

logfile = "/Users/gest/Eternum/intel/system_logs/launchctl_list.log"
output = "/Users/gest/Eternum/intel/ghostwire_crosscheck_report.txt"

with open(logfile, "r") as f, open(output, "w") as out:
    out.write(f"# GHOSTWIRE CROSSCHECK REPORT — {datetime.now()}\n\n")
    for line in f:
        for word in WATCHLIST:
            if re.search(word, line, re.IGNORECASE):
                out.write(f"[!] Match: {word} → {line}")
