#!/bin/zsh

IPFS_LOG="$HOME/Eternum/engine_logs/ipfs_publish_log.txt"
mkdir -p "$(dirname "$IPFS_LOG")"

echo "\n🌐 [$(date)] Starting IPFS auto-push..." >> "$IPFS_LOG"

TARGETS=(
  "$HOME/Eternum/engine_logs/whisper_log_0418.txt"
  "$HOME/Eternum/intel/surveillance_dataset/index.json"
  "$HOME/Eternum/vaults/active_mints/SAVEDAN_index.json"
  "$HOME/Eternum/engine_logs/long_logs"
)

for file in "${TARGETS[@]}"; do
  if [ -e "$file" ]; then
    CID=$(ipfs add -qr "$file" 2>/dev/null | tail -n1)
    echo "📎 $file → $CID" >> "$IPFS_LOG"
  else
    echo "❌ File not found: $file" >> "$IPFS_LOG"
  fi
done

echo "✅ IPFS Ping Complete — $(date)" >> "$IPFS_LOG"
