#!/usr/bin/env python3
"""
🌱 Mycelium Automator Core — Eternum Engine v1.0

Growth pattern mapped from real fungi: exploration, balancing, exploitation.
Auto-vaults with every evolution cycle.
"""

import os
import subprocess
from datetime import datetime

ENGINE_PATH = os.path.expanduser("~/Eternum/Shell")
LOG_PATH = os.path.expanduser("~/Eternum/engine_logs")
VAULT_PATH = os.path.expanduser("~/Eternum/vaults")

def log(msg):
    print(f"[Mycelium] {msg}")
    os.makedirs(LOG_PATH, exist_ok=True)
    with open(f"{LOG_PATH}/mycelium_log.txt", "a") as f:
        f.write(f"[{datetime.now()}] {msg}\n")

def auto_vault():
    log("📦 Vaulting metadata...")
    os.makedirs(VAULT_PATH, exist_ok=True)
    src_file = os.path.expanduser("~/Eternum/data_logs/critical_time_cluster.csv")
    dst_file = os.path.join(VAULT_PATH, f"vault_cluster_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")
    
    if os.path.exists(src_file):
        try:
            subprocess.run(["cp", src_file, dst_file], check=True)
            log(f"✅ Vaulted to: {dst_file}")
        except subprocess.CalledProcessError as e:
            log(f"❌ Vaulting failed: {e}")
    else:
        log("⚠️ Source data log not found. Vaulting skipped.")

def absorb_and_fruit():
    log("🍄 Absorbing data... forming fruiting body.")
    auto_vault()
    log("⏸️  Pausing... awaiting Whisper sync.")
