#!/bin/zsh

LOG_DIR="$HOME/Eternum/engine_logs"
LOG="$LOG_DIR/reroute_log_$(date +%Y%m%d_%H%M).txt"

# Ensure all needed directories exist
mkdir -p "$LOG_DIR" "$HOME/Eternum/intel/network_logs"

echo "🔀 REROUTE MODULE START — $(date)" > "$LOG"

# Define ports to monitor
PORTS=("9002" "443" "5228" "11110")

for port in $PORTS; do
  PIDS=$(lsof -iTCP:$port -sTCP:ESTABLISHED -t 2>/dev/null)
  for pid in $PIDS; do
    echo "🔁 Rerouting PID $pid (Port $port)" | tee -a "$LOG"
    echo "reroute:$pid:$port" >> "$HOME/Eternum/intel/network_logs/decoy_beacons.log"
    
    # Try rerouting via process stop/resume as trap logic
    kill -STOP $pid && sleep 0.5 && kill -CONT $pid &
  done
done

echo "✅ Reroute sweep complete. Log saved at: $LOG"

