#!/bin/zsh
DATE=$(date +%Y%m%d_%H%M)
DEST="$HOME/Eternum/vaults/burns/burn_$DATE.json.gpg"
mkdir -p ~/Eternum/vaults/burns

echo "🧱 Bundling whisper log + surveillance dataset..."
cat ~/Eternum/engine_logs/whisper_log_0418.txt ~/Eternum/intel/surveillance_dataset/index.json > /tmp/burn_tmp_$DATE.json

echo "🔐 Encrypting bundle..."
gpg -c /tmp/burn_tmp_$DATE.json
mv /tmp/burn_tmp_$DATE.json.gpg "$DEST"
rm /tmp/burn_tmp_$DATE.json

echo "🔥 Log burned to $DEST"
