#!/usr/bin/env python3
import time, os, socket
from datetime import datetime

LOG_PATH = os.path.expanduser("~/Eternum/engine_logs/whisper_trap.log")

def log(msg):
    with open(LOG_PATH, "a") as f:
        f.write(f"[{datetime.now()}] {msg}\n")
    print(f"[WHISPER] {msg}")

def scan_ports(ports):
    for port in ports:
        s = socket.socket()
        s.settimeout(1)
        result = s.connect_ex(("localhost", port))
        if result == 0:
            log(f"🟥 Port {port} OPEN — potential probe detected")
        else:
            log(f"✅ Port {port} CLOSED")
        s.close()

while True:
    scan_ports([22, 80, 443, 8080, 1337])
    time.sleep(60)
