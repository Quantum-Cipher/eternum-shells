#!/bin/bash

# Kill all known wireless interfaces safely
echo "[ETERNUM] 🚫 Disabling Wi-Fi for local isolation..."

# Turn off default wireless interface (Mac default is en0)
networksetup -setairportpower en0 off

# Optional: Disable other possible interfaces (if using USB WiFi, etc.)
# networksetup -setnetworkserviceenabled "Wi-Fi 2" off

# Confirm and log
echo "[ETERNUM] ✅ Wi-Fi is now off. You are operating offline." >> ~/Eternum/engine_logs/network_lock.log
